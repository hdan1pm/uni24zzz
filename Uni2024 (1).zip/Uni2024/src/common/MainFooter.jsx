import './MainFooter.css'
function MainFooter() {
    return (
        <footer id='main-footer'>
            <div className="container">
            2024 Todos los derechos reservados
            </div>
        </footer>
    )
}

export default MainFooter