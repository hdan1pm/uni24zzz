function MainHeader() {
  return (
    <header>
        <div className="container">
        <h1>Ideas Digitales</h1>
        <p>Vine, ví y vencí</p>
        </div>
    </header>
  )
}

export default MainHeader