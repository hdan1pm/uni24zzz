import './Nosotros.css'
function Nosotros() {
    return (
        <section id='nosotros' className='padded'>
            <div className="container">
                <h2>Nosotros</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex, ut dolores? Maxime in vero porro fugit quo repellendus accusamus id ullam repellat enim alias, quaerat pariatur, cum vitae sunt? Sit nulla sapiente molestiae atque tempora voluptatibus autem dolore quo omnis maiores minima porro obcaecati, vel, officia quisquam molestias, qui pariatur ducimus possimus similique! Est perspiciatis amet quibusdam magnam voluptatum eos nostrum magni aspernatur aliquid unde quaerat quam quos tenetur, adipisci doloremque eius, cupiditate nobis atque. Labore, sequi magnam natus cum porro eos culpa eligendi illo doloremque ea quisquam in debitis facere. Ipsa a eius ducimus voluptatum laudantium neque accusantium doloribus minima libero veritatis, perferendis consequuntur recusandae nesciunt! Molestiae deleniti dolore corporis eius veniam, possimus dolorum quo facilis rem tempora omnis.</p>
            </div>
        </section>
    )
}

export default Nosotros